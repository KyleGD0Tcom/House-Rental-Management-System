<?php
include 'databaseConn.php';

$notif = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Extract form data
    $insertdate = date('Y-m-d', strtotime($_POST['regDate']));
    $middle = $_POST['midName'];
    $fname = $_POST['firstName'];
    $lname = $_POST['lastName'];
    $email = $_POST['email'];
    $contact = $_POST['contactNumber'];
    $houseid = $_POST['house'];
    $date1 = new DateTime($insertdate);
    $date2 = new DateTime();
    $interval = $date1->diff($date2);
    $months = ($interval->y * 12) + $interval->m;

    // Begin transaction
    $conn->begin_transaction();

    try {
        
        $stmt = $conn->prepare("CALL insert_tenant(?, ?, ?, ?, ?, ?, ?, ?)");
        
       
        $stmt->bind_param("sssssssi", $fname, $lname, $middle, $email, $contact, $houseid, $insertdate, $months);

       
        if ($stmt->execute()) {
            
            $conn->commit();
            $notif = 'Tenant added';
            header("Location: dashboard.php?page=tenants&notif=" . urlencode($notif));
            exit; 
        } else {
            
            $conn->rollback();
            echo "Error: " . $stmt->error;
        }

        
        $stmt->close();
    } catch (Exception $e) {
        
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }
}


$conn->close();
?>
