<?php
include 'databaseConn.php';

$query = $conn->query("SELECT * FROM `tenants` WHERE `id` = '{$_POST['id']}'");
if ($query->num_rows > 0) {
	$data['result'] = '';
	$tdata = $query->fetch_assoc();
	
	$data['id'] = $tdata['id'];
	$price = '';
	$sql2 = $conn->query("SELECT price FROM houses WHERE id = {$tdata['house_id']}");


	if ($sql2->num_rows > 0) {
		$hdata = $sql2->fetch_assoc();
		$data['price'] = $hdata['price'];
		$price = $hdata['price'];
	}
	
	$date1_str = date("F j, Y", strtotime($tdata['date_in']));
	$data['date'] = $date1_str;
    $months = $tdata['months_payable'];
	
	$data['m'] = $tdata['months_payable'];
	if ($months == 0) {
		$data['month'] = 0;
	} else {
		$total =  $months * $price;
		if ($months == 1) {
			$data['month'] = $months . " month   (Php {$total})";
		} else {
			$data['month'] = $months . " months  (Php {$total})";
		}
		
	}


	$data['status'] = 'ok';
	$data['result'] = $tdata;
} else {
	$data['status'] = 'err';
	$data['result'] = '';
}

echo json_encode($data);

