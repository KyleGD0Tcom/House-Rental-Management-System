<p class="mt-4">Welcome Back Admin!</p>
<hr>
<?php
$sql = "SELECT * From counts";
$sql2 = "SELECT * From total_payments_view";
$row = $conn->query($sql)->fetch_assoc();
$row2 = $conn->query($sql2)->fetch_assoc();

?>

<div class="container d-flex justify-content-around mt-5">
    <div class="houses">
        <div class="card border-primary">
            <div class="card-body bg-primary">
                <div class="card-body text-white">
                    <span class="float-right summary_icon"> <i class="material-symbols-outlined ">house</i></span>
                    <h4><b>
 <?php echo $row["house_count"];?>
                        </b></h4>
                    <p><b>Total Houses</b></p>
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-12">
                        <a href="dashboard.php?page=houses" class="text-primary float-right">View List <span
                                class="fa fa-angle-right"></span></a>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="tenants">

        <div class="card border-warning">
            <div class="card-body bg-warning">
                <div class="card-body text-white">
                    <span class="float-right"> <i class="float-right material-symbols-outlined">
                            person
                        </i></span>

                    <h4><b>
                           <?php echo $row['tenant_count']?> 
                        </b></h4>
                    <p><b>Total Tenants</b></p>
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-12">
                        <a href="dashboard.php?page=tenants" class="text-primary float-right">View List <span
                                class="fa fa-angle-right"></span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="payments ">

        <div class="card border-success">
            <div class="card-body bg-success">
                <div class="card-body text-white">
                    <span class="float-right summary_icon"> <i class="material-symbols-outlined ">payments</i></span>
                    <h4><b>
                    ₱ <?php echo $row2['total_payments'] == 0 ? 0: $row2['total_payments']?>
                        </b></h4> 
                    <p><b>Payments This Month</b></p>
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-12">
                        <a href="dashboard.php?page=payments" class="text-primary float-right">View Payments <span
                                class="fa fa-angle-right"></span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>