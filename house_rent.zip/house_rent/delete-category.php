<?php
include 'databaseConn.php';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {

    $id = $_POST['idDelete'];

    $sql = "DELETE FROM `categories` WHERE id='$id'";
    $result = $conn->query($sql);
    if ($result == true) {
        header("Location: dashboard.php?page=house-type");
    }
}
$conn->close();
?>