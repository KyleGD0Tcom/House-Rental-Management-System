<?php
include 'databaseConn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
 
    $name = $_POST['category'];
    $id = $_POST['newName'];


    $sql = "UPDATE `categories` SET `name`=? WHERE id=?";
    $stmt = $conn->prepare($sql);

  
    $stmt->bind_param("si", $name, $id);

  
    if ($stmt->execute()) {
        header("Location: dashboard.php?page=house-type");
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
