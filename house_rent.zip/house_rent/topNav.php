<nav class="navbar bg-body-tertiary">
    <div class="container-fluid p-2">
        <a class="navbar-brand"> RentEase: Streamlined Home Rental Management</a>
        <a class="nav-link dropdown-toggle mx-3" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Administrator
        </a>
        <ul class="dropdown-menu dropdown-menu-end m">
            <li><a class="dropdown-item" href="#">Manage Account</a></li>
            <li><a class="dropdown-item" href="#">Logout</a></li>

        </ul>


    </div>
    </div>
</nav>