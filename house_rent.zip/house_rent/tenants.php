<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
?>
<p>Current tenants</p>
<input type="button" value="Add Tenant" class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#addHouses">
<table id="myTable" class="table table-success table-striped mb-4">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>House Rented</th>
            <th>Montly Rate</th>
            <th>Months Payable</th>
            <th>Last Payment</th>
            <th>Total Months Payed</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sql = "SELECT * FROM tenant_details";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()):
            $price = '';
            $last_payment = $row['last_payment'] === null ? 'N/A' : $row['last_payment'];
            if($last_payment == 'N/A'){
                $date_str = "N/A";
            }else
         	$date_str = date("F j, Y", strtotime($last_payment));
            ?>
            <tr>
                <td><?php echo $row['id'] ?></td>
                <td><?php echo $row['first_name'] . " " . $row['middle_name'] . " " . $row['last_name'] ?></td>
                <td>
                    <?php echo $row['house_rented'] ?>
                </td>
                <td><?php echo $row['monthly_rate']?></td>
                <td><?php echo $row['months_payable'] ?></td>
                <td><?php echo $date_str ?></td>
                <td><?php echo $row['total_months_payed']?></td>
                <td class="d-flex">
                    <input type="hidden" class="hidden_fname" value="<?php echo $row['first_name'] ?>">
                    <input type="hidden" class="hidden_lname" value="<?php echo $row['last_name'] ?>">
                    <input type="hidden" class="hidden_mname" value="<?php echo $row['middle_name'] ?>">
                    <input type="hidden" class="hidden_email" value="<?php echo $row['email'] ?>">
                    <input type="hidden" class="hidden_id" value="<?php echo $row['id'] ?>">
                    <input type="hidden" class="hidden_contact" value="<?php echo $row['contact'] ?>">
                    <button class="btn btn-secondary mx-2 edit-tenant" data-bs-toggle="modal"
                        data-bs-target="#editHouses">Edit</button>
                    <button class="btn btn-warning">Delete</button>
                </td>
            </tr>

        <?php endwhile ?>
    </tbody>
</table>



<div class="modal fade" id="addHouses" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="add-tenant.php" method="POST">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">New tenant</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <label for="lastName">Last name</label>
                    <input type="text" class="form-control " name="lastName">
                    <label for="firstName">firstName</label>
                    <input type="text" class="form-control " name="firstName">
                    <label for="midName">Middle name</label>
                    <input type="text" class="form-control " name="midName">
                    <label for="email">Email</label>
                    <input type="email" class="form-control " name="email">
                    <label for="contactNumber">Contact #</label>
                    <input type="number" class="form-control " name="contactNumber">
                    <label for="house">House Number</label>
                    <div class="input-group mb-3">

                        <select class="form-select" id="inputGroupSelect02" name="house">
                            <option selected>Choose...</option>
                            <?php
                            $sql = "SELECT * FROM houses WHERE status='Available'";
                            $result = $conn->query($sql);
                            while ($row = $result->fetch_assoc()) {
                                echo "
                               <option value=" . $row["id"] . ">" . $row["house_number"] . "</option>";

                            }
                            ?>
                        </select>

                    </div>
                    <label for="regDate">Registration Date</label>
                    <input type="date" name="regDate" class="form-control">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="submit">Save Tenant</button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- edit -->


<div class="modal fade" id="editHouses" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="edit-tenant.php" method="POST">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Edit tenant</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <label for="lastName">Last name</label>
                    <input type="hidden" name="id" class="hidden_id2">
                    <input type="text" class="form-control hidden_lname2" name="lastName">
                    <label for="firstName">firstName</label>
                    <input type="text" class="form-control hidden_fname2" name="firstName">
                    <label for="midName">Middle name</label>
                    <input type="text" class="form-control hidden_mname2" name="midName">
                    <label for="email">Email</label>
                    <input type="email" class="form-control hidden_email2" name="email">
                    <label for="contactNumber">Contact #</label>
                    <input type="number" class="form-control hidden_contact2" name="contactNumber">


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="submit">Update Tenant</button>
                </div>
            </form>
        </div>
    </div>
</div>