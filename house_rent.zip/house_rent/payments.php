<div class="">
    <input type="button" value="Add Payment" class="btn btn-primary mt-3" data-bs-toggle="modal"
        data-bs-target="#Payments" id="adPay">
</div>
<table id="myTable" class="table table-success table-striped mb-4">
 
    <thead>
        <tr>
            <th> #</th>
            <th>Date</th>
            <th>Tenant</th>
            <th>Months Payed</th>
            
        </tr>
    </thead>
    <tbody>
        <?php
        $sql = "SELECT * FROM payments";
        $result = $conn->query($sql);
        
        while ($row = $result->fetch_assoc()):
            $name = '';
            $sql2 = "SELECT * FROM tenants WHERE id={$row['tenant_id']}";
            $result2 = $conn->query($sql2);
            while ($row2 = $result2->fetch_assoc()) {
                $name = $row2['last_name'] . "," . $row2['first_name'] . " " . $row2['middle_name'];
            }
             $date = date('F j, Y', strtotime($row['date_pay']));
            ?>
            <tr>
                <td><?php echo $row['id'] ?></td>
                <td><?php echo $date?></td>
                <td><?php echo $name?></td>
                <td><?php echo $row['months_payed']?></td>
               
            </tr>

        <?php endwhile ?>

    </tbody>


</table>
<?php

?>

<div class="modal fade" id="Payments" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="add-payment.php" method="POST">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Add Payments</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <label for="tenant">Tenant</label>
                    <div class="input-group mb-3">

                        <select class="form-select" id="tenants" name="tenant">
                            <option selected value="0">Choose...</option>
                            <?php
                            $sql = "SELECT * FROM tenants";
                            $result = $conn->query($sql);

                            while ($row = $result->fetch_assoc()) {
                                echo "
                               <option value=" . $row["id"] . ">" . $row["last_name"] . ", " . $row["first_name"] . "," . $row["middle_name"] . "</option>";
                            }
                            ?>
                        </select>

                    </div>
                    <div class="form-group" id="details" style="display:none">
                        <large><b>Details</b></large>
                        <hr>
                        <p>Tenant: <b class="tname"></b></p>
                        <p>Monthly Rental Rate: <b class="price"></b></p>
                       
                        <p>Rent Started: <b class='rent_started'></b></p>
                        <p>Payable Months: <b class="payable_months"></b></p>
                        <hr>
                    </div>
                    <div id="textt" style="display:none"></div>
                    <label for="monthPay" id="labelf">Select Months to Pay</label>
                    <select name="monthPay" id="monthpay" class="form-select">

                    </select>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="forsave" name="submit">Save Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div id="details_clone" style="display:none">
    <div class="d">
    </div>
</div>