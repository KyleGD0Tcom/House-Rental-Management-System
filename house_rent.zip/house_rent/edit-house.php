<?php
include 'databaseConn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {

    $housenumber = $_POST['housenumber'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $houseid = $_POST['house_id'];


    $conn->begin_transaction();

    try {

        $sql = "UPDATE `houses` SET `house_number`=?, `description`=?, `price`=? WHERE `id`=?";
        $stmt = $conn->prepare($sql);


        $stmt->bind_param("ssdi", $housenumber, $description, $price, $houseid);


        if ($stmt->execute()) {

            $conn->commit();
            header("Location: dashboard.php?page=houses");
            exit;
        } else {

            $conn->rollback();
            echo "Error: " . $stmt->error;
        }


        $stmt->close();
    } catch (Exception $e) {

        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }
}


$conn->close();
?>