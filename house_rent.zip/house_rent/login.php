<?php

include 'databaseConn.php';
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['username']) && isset($_POST['password'])) {

    $username = stripslashes($_REQUEST['username']);
    $username = mysqli_real_escape_string($conn, $username);
    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($conn, $password);


    $query = "SELECT username FROM users WHERE username='$username'
    AND password='" . md5($password) . "'";
    $result = mysqli_query($conn, $query) or die(mysql_error());
    $rows = mysqli_num_rows($result);
    if ($rows == 1) {
        $_SESSION['username'] = $username;

        header("Location: dashboard.php");

    } else {
        $error = "incorrect password!";
    }


}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'links.php' ?>
    <title>Login</title>

    <style>
        * {
            padding: 0 !important;
            margin: 0 !important;
        }

        #left {
            width: 60%;
            height: 100vh;
        }

        #right {
            width: 40%;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .img {
            width: 100%;
            height: 100%;
            border-radius: 10px;
        }

        form {
            display: flex;
            flex-direction: column;
            background-color: rgb(255, 255, 250);
            width: 370px;
            height: 300px;
            padding: 10px !important;
            border-radius: 10px;
        }

        input {
            height: 40px;
            border-radius: 4px;
        }
    </style>
</head>

<body class="d-flex ">
    <div class="container bg-secondary p-2" id="left">
        <img src="img/house-rent.jpg" alt="" class="img">
    </div>
    <div class="container bg-primary p-2" id="right">
        <div class="title">
            <h1>RentEase</h1>
        </div>
        <div class="form mt-5">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">

                <?php if (isset($error)) { ?>
                    <p class="error" style="color:red; font-size: 15px; text-align: center;"><?php echo $error; ?></p>
                <?php } ?>

                <label for="username" class="mt-4">Username</label>
                <input type="text" name="username" id="username" class="mb-4">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="mb-5">
                <input type="submit" value="Login" class="btn btn-primary">
            </form>
        </div>

    </div>

</body>

</html>