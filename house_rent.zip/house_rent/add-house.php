<?php
include 'databaseConn.php';

$notif = '';


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['housenumber']) && isset($_POST['categoryType']) && isset($_POST['description']) && isset($_POST['price'])) {

    $housenumber = $_POST['housenumber'];
    $type = $_POST['categoryType'];
    $price = $_POST['price'];
    $descrip = $_POST['description'];


    $conn->begin_transaction();

    try {

        $sql = "INSERT INTO houses (house_number, house_type, description, price, status)
                VALUES ('$housenumber', '$type', '$descrip', '$price', 'Available')";

        if ($conn->query($sql) === TRUE) {

            $conn->commit();
            $notif = 'House Added Successfully';
            header("Location: dashboard.php?page=houses&notif=" . urlencode($notif));
            exit;
        } else {

            $conn->rollback();

            $notif = $conn->error;
            header("Location: dashboard.php?page=houses&notif=" . urlencode($notif));
        }
    } catch (Exception $e) {

        $conn->rollback();
        $notif = $e->getMessage();
        header("Location: dashboard.php?page=houses&notif=" . urlencode($notif));
    }
}


$conn->close();
?>