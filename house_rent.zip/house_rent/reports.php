<p class="mt-4"><b>REPORTS</b></p>
<hr>
<?php 
$sql = "SELECT * FROM reports";
$row = $conn->query($sql)->fetch_assoc();
?>
<div class="container d-flex justify-content-around mt-5">
    <div class="houses">
        <div class="card border-primary">
            <div class="card-body bg-primary">
                <div class="card-body text-white">
                    <span class="float-right summary_icon"> <i class="material-symbols-outlined ">house</i></span>
                    <h4><b>
<?php echo $row["occupied_houses"];?>
                        </b></h4>
                    <p><b>Total Occupied Houses</b></p>
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-12">
                        <a href="dashboard.php?page=houses" class="text-primary float-right">View List <span
                                class="fa fa-angle-right"></span></a>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="tenants">

        <div class="card border-warning">
            <div class="card-body bg-warning">
                <div class="card-body text-white">
                <span class="float-right summary_icon"> <i class="material-symbols-outlined ">house</i></span>
                    <h4><b>
                    <?php echo $row["available_houses"];?>
                        </b></h4>
                    <p><b>Total Available Houses</b></p>
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-12">
                        <a href="dashboard.php?page=tenants" class="text-primary float-right">View List <span
                                class="fa fa-angle-right"></span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="payments ">

        <div class="card border-success">
            <div class="card-body bg-success">
                <div class="card-body text-white">
                    <span class="float-right summary_icon"> <i class="material-symbols-outlined ">payments</i></span>
                    <h4><b>
                    ₱    <?php echo $row["total_receivable"] == 0 ? 0: $row['total_receivable'];?>
                        </b></h4> 
                    <p><b>Total Payments Receivable</b></p>
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-12">
                        <a href="dashboard.php?page=payments" class="text-primary float-right">View Payments <span
                                class="fa fa-angle-right"></span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>