<?php
session_start();
include 'databaseConn.php';

if(!isset($_SESSION['username'])){
  header('Location : login.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php include 'links.php' ?>
  <link rel="stylesheet" href="dashboard.css">
  <style>

  </style>
  <title>Dashboard</title>
</head>

<body>
  <?php
  include 'navigation.php'
    ?>

</body>
<script src="dashboard.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>

<script>
  $(document).ready(function () {
    $('#myTable').DataTable({
      "pageLength": 5,
      "lengthChange": false,
      "language": {
        "info": "Showing 5 entries"
      }
    });

    $(".edit").on('click', function () {
      var name = $(this).closest('tr').find('.name').val();
      var id = $(this).closest('tr').find('.id').val()
      $("#name").val(name);
      $(".newName").val(id);
    });
    $(".edithouse").on('click', function () {
      var description_edit = $(this).closest('tr').find('.description_current').val();
      var price = $(this).closest('tr').find('.price_current').val();
      var house_number = $(this).closest('tr').find('.house_number_current').val();
      var house_id_edit = $(this).closest('tr').find('.house_id_edit').val()
      var house_type_edit = $(this).closest('tr').find('.house_type_edit').val()
      $("#description_edit").val(description_edit);
      $("#price_edit").val(price);
      $(".house_number_edit").val(house_number);
      $(".house_id").val(house_id_edit);
    });

    $(".delete").on('click', function () {

      var id2 = $(this).closest('tr').find('.id').val()
      $(".idDelete").val(id2);

    });

    $(".edit-tenant").on('click', function () {
      var fname = $(this).closest('tr').find('.hidden_fname').val();
      var lname = $(this).closest('tr').find('.hidden_lname').val();
      var mname = $(this).closest('tr').find('.hidden_mname').val();
      var email = $(this).closest('tr').find('.hidden_email').val();
      var contact = $(this).closest('tr').find('.hidden_contact').val();
      var id = $(this).closest('tr').find('.hidden_id').val();

      $(".hidden_fname2").val(fname);
      $(".hidden_lname2").val(lname);
      $(".hidden_mname2").val(mname);
      $(".hidden_email2").val(email);
      $(".hidden_contact2").val(contact);
      $(".hidden_id2").val(id);

    });


    $("#tenants").on('change', function () {
      if ($("#tenants").val() == 0) {
        $("#details").css("display", "none");

      } else {
        var id = $("#tenants").val();
        $.ajax({
          type: 'POST',
          url: 'ajax.php',
          dataType: "json",
          data: { id: id },
          success: function (data) {
            if (data.status == 'ok') {
              $(".tname").text(data.result.last_name + ", " + data.result.first_name + " " + data.result.middle_name);
              $(".price").text(data.price);
              $(".total_paid").text(113);
              $(".rent_started").text(data.date);
              $(".payable_months").text(data.month);
              var m = data.m;
              var $select = $('#monthpay');

            
              if (m == 0) {
                $('#forsave').hide();
                $('#monthpay').hide();
                $('#textt').html('<b>Please Pay Next Month');
                $('#textt').css("display", "block");
                $('#labelf').hide();
                $("#details").css("display", "block");
                console.log(data.result.last_name);
                console.log(data.id);
              } else if (m > 0) {
                console.log(data.result.last_name);

                $('#forsave').show();
                $('#textt').hide();
                $('#monthpay').show();
                $('#labelf').show();
                for (var i = 1; i <= m; i++) {
                  var $option = $('<option>', {
                    value: i,
                    text: i,
                    selected: i === 1
                  });
                  $select.append($option);
                }
                $select.prop('disabled', false);
                $("#details").css("display", "block");
              }

            } else {
              $('#textt').html('<b>error');
            }

          }
        });

      }

    });

  });


</script>

</html>

<?php

?>