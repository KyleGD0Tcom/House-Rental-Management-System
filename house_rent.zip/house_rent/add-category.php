<?php

include 'databaseConn.php';

$notif = '';


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['category'])) {

    $name = $_POST['category'];


    $conn->begin_transaction();

    try {

        $sql = "CALL insert_category('$name')";

        if ($conn->query($sql) === TRUE) {

            $conn->commit();
            $notif = 'Category Added Successfully';
            header("Location: dashboard.php?page=house-type&notif=" . urlencode($notif));
            exit;
        } else {

            $conn->rollback();
            $notif = $conn->error;
            header("Location: dashboard.php?page=house-type&notif=" . urlencode($notif));
        }
    } catch (Exception $e) {

        $conn->rollback();
        $notif = $e->getMessage();
        header("Location: dashboard.php?page=house-type&notif=" . urlencode($notif));
    }
}


$conn->close();

?>