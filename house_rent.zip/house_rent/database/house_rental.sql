-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2024 at 03:23 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `house_rental`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_category` (IN `p_name` VARCHAR(255))   BEGIN
INSERT INTO `categories`(`name`) values(p_name);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_tenant` (IN `p_first_name` VARCHAR(255), IN `p_last_name` VARCHAR(255), IN `p_middle_name` VARCHAR(255), IN `p_email` VARCHAR(255), IN `p_contact` VARCHAR(255), IN `p_house_id` INT(10), IN `p_date_in` DATE, IN `p_months_payable` INT(10))   BEGIN
    INSERT INTO tenants (first_name, last_name, middle_name, email, contact, house_id, date_in,months_payable)
    VALUES (p_first_name, p_last_name, p_middle_name, p_email, p_contact, p_house_id, p_date_in,p_months_payable);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(24, 'Single Family Home'),
(25, 'Appartment');

-- --------------------------------------------------------

--
-- Stand-in structure for view `counts`
-- (See below for the actual view)
--
CREATE TABLE `counts` (
`house_count` bigint(21)
,`tenant_count` bigint(21)
);

-- --------------------------------------------------------

--
-- Table structure for table `houses`
--

CREATE TABLE `houses` (
  `id` int(11) NOT NULL,
  `house_number` int(11) NOT NULL,
  `house_type` int(20) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` int(20) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `houses`
--

INSERT INTO `houses` (`id`, `house_number`, `house_type`, `description`, `price`, `status`) VALUES
(46, 1, 24, '2 rooms', 5000, 'Occupied'),
(47, 2, 25, '1 Bedroom', 3000, 'Occupied');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) NOT NULL,
  `tenant_id` int(20) NOT NULL,
  `months_payed` int(20) NOT NULL,
  `date_pay` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `tenant_id`, `months_payed`, `date_pay`) VALUES
(37, 51, 4, '2024-06-02');

--
-- Triggers `payments`
--
DELIMITER $$
CREATE TRIGGER `update_total_months_payed` AFTER INSERT ON `payments` FOR EACH ROW BEGIN
    UPDATE tenants
    SET total_months_payed = total_months_payed + NEW.months_payed,  months_payable = months_payable - NEW.months_payed,last_payment = CURRENT_DATE
    WHERE id = NEW.tenant_id;
    
       
  
    


END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `reports`
-- (See below for the actual view)
--
CREATE TABLE `reports` (
`available_houses` bigint(21)
,`occupied_houses` bigint(21)
,`total_receivable` varchar(90)
);

-- --------------------------------------------------------

--
-- Table structure for table `tenants`
--

CREATE TABLE `tenants` (
  `id` int(30) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `middle_name` varchar(25) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `house_id` int(30) NOT NULL,
  `date_in` date NOT NULL,
  `months_payable` int(30) NOT NULL,
  `last_payment` date DEFAULT NULL,
  `total_months_payed` int(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tenants`
--

INSERT INTO `tenants` (`id`, `first_name`, `last_name`, `middle_name`, `email`, `contact`, `house_id`, `date_in`, `months_payable`, `last_payment`, `total_months_payed`) VALUES
(51, 'Loui', 'Alejar', 'Paras', 'louiparas@gmail.com', '09292823663', 47, '2023-06-02', 8, '2024-06-02', 4);

--
-- Triggers `tenants`
--
DELIMITER $$
CREATE TRIGGER `update_house_status` AFTER INSERT ON `tenants` FOR EACH ROW BEGIN
 UPDATE houses set status='Occupied' where id = NEW.house_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `tenant_details`
-- (See below for the actual view)
--
CREATE TABLE `tenant_details` (
`id` int(30)
,`first_name` varchar(255)
,`last_name` varchar(255)
,`middle_name` varchar(25)
,`house_rented` int(11)
,`monthly_rate` int(20)
,`months_payable` int(30)
,`last_payment` date
,`contact` varchar(255)
,`email` varchar(255)
,`total_months_payed` int(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `total_payments_view`
-- (See below for the actual view)
--
CREATE TABLE `total_payments_view` (
`total_payments` varchar(84)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`) VALUES
(2, 'Administrator', 'admin', '6768ec9bd917e30a6b14df3cd7aff288');

-- --------------------------------------------------------

--
-- Structure for view `counts`
--
DROP TABLE IF EXISTS `counts`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `counts`  AS SELECT count(`houses`.`id`) AS `house_count`, (select count(`tenants`.`id`) from `tenants`) AS `tenant_count` FROM `houses` ;

-- --------------------------------------------------------

--
-- Structure for view `reports`
--
DROP TABLE IF EXISTS `reports`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reports`  AS SELECT (select count(`houses`.`id`) from `houses` where `houses`.`status` = 'Available') AS `available_houses`, (select count(`houses`.`id`) from `houses` where `houses`.`status` = 'Occupied') AS `occupied_houses`, (select format(sum(`h`.`price` * `t`.`months_payable`),2) from (`houses` `h` join `tenants` `t` on(`t`.`house_id` = `h`.`id`))) AS `total_receivable` ;

-- --------------------------------------------------------

--
-- Structure for view `tenant_details`
--
DROP TABLE IF EXISTS `tenant_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `tenant_details`  AS SELECT `t`.`id` AS `id`, `t`.`first_name` AS `first_name`, `t`.`last_name` AS `last_name`, `t`.`middle_name` AS `middle_name`, `h`.`house_number` AS `house_rented`, `h`.`price` AS `monthly_rate`, `t`.`months_payable` AS `months_payable`, `t`.`last_payment` AS `last_payment`, `t`.`contact` AS `contact`, `t`.`email` AS `email`, `t`.`total_months_payed` AS `total_months_payed` FROM (`tenants` `t` join `houses` `h` on(`t`.`house_id` = `h`.`id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `total_payments_view`
--
DROP TABLE IF EXISTS `total_payments_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `total_payments_view`  AS SELECT format(sum(`h`.`price` * `p`.`months_payed`),2) AS `total_payments` FROM ((`payments` `p` join `tenants` `t` on(`p`.`tenant_id` = `t`.`id`)) join `houses` `h` on(`t`.`house_id` = `h`.`id`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_house_type` (`house_type`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_tenant_ids` (`tenant_id`);

--
-- Indexes for table `tenants`
--
ALTER TABLE `tenants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_house_id` (`house_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `houses`
--
ALTER TABLE `houses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tenants`
--
ALTER TABLE `tenants`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `houses`
--
ALTER TABLE `houses`
  ADD CONSTRAINT `fk_house_type` FOREIGN KEY (`house_type`) REFERENCES `categories` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `houses_ibfk_1` FOREIGN KEY (`house_type`) REFERENCES `categories` (`id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `fk_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`),
  ADD CONSTRAINT `fk_tenant_ids` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tenants`
--
ALTER TABLE `tenants`
  ADD CONSTRAINT `fk_house_id` FOREIGN KEY (`house_id`) REFERENCES `houses` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tenants_ibfk_1` FOREIGN KEY (`house_id`) REFERENCES `houses` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
