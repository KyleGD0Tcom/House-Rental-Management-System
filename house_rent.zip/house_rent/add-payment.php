<?php

include 'databaseConn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    
    $tenant_id = $_POST['tenant'];
    $months_pay = $_POST['monthPay'];

 
    $conn->begin_transaction();

    try {
       
        $stmt = $conn->prepare("INSERT INTO `payments`(`tenant_id`, `months_payed`) VALUES (?, ?)");         
        $stmt->bind_param("ii", $tenant_id, $months_pay);
        if ($stmt->execute()) {
         
            $conn->commit();
            header("Location: dashboard.php?page=payments");
            exit; 
        } else {
            
            $conn->rollback();
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } catch (Exception $e) {
        
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }
}


$conn->close();

?>
