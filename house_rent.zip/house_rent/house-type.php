<?php
if (isset($_GET['notif'])) {
    $notif = urldecode($_GET['notif']);
    echo "<div class='alert alert-success d-flex align-items-center alert-dismissible fade show' role='alert'>
    
     <div>
     $notif
     </div>
    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button> 
    </div>";
}
?>
<div class="">
    <input type="button" value="Add Category" class="btn btn-primary mt-3" data-bs-toggle="modal"
        data-bs-target="#addCategory">
</div>
<table id="myTable" class="table table-success table-striped mb-4">
    <thead>
        <tr>
            <th>#</th>
            <th>Category</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sql = "SELECT * FROM categories";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()):
            ?>

            <tr>
                <td><?php echo $row["id"] ?></td>
                <td><?php echo $row["name"] ?></td>
                <input type="hidden" class="name" name="name" value="<?php echo $row['name'] ?>">
                <input type="hidden" class="id" name="id" value="<?php echo $row["id"] ?>">
                <td>
                    <input type='button' value='Edit' class='btn btn-primary edit' data-bs-toggle='modal' id='edit'
                        data-bs-target='#editCategory'>
                    <input type='button' value='Delete' class='btn btn-danger delete' data-bs-toggle='modal' id='delete'
                        data-bs-target='#deleteCategory'>
                </td>
            </tr>

        <?php endwhile ?>


    </tbody>


</table>

<div class="modal fade" id="addCategory" tabindex="-1" aria-labelledby="add" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="add-category.php" method="POST">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="add">Add Category</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="text" class="form-control" name="category">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Category</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- edit -->

<div class="modal fade" id="editCategory" tabindex="-1" aria-labelledby="edit" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="update-category.php" method="POST">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="edit">Edit Category</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="text" class="form-control" name="category" id="name">
                    <input type="hidden" name="newName" class="newName">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="submit">Save Category</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- delte -->

<div class="modal fade" id="deleteCategory" tabindex="-1" aria-labelledby="delete" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="delete-category.php" method="POST">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="delete">Are you sure you want to delete this Category?</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <input type="hidden" name="idDelete" class="idDelete">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger" name="submit">Confirm Delete</button>
                </div>
            </form>
        </div>
    </div>
</div>