<div class="">
    <input type="button" value="Add Houses" class="btn btn-primary mt-3" data-bs-toggle="modal"
        data-bs-target="#addHouses">
</div>

<table id="myTable" class="table table-success table-striped mb-4">
    <caption>Current Houses</caption>
    <thead>
        <tr>
            <th>House #</th>
            <th>House</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sql = "SELECT * FROM houses";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()):
            $sql2 = "SELECT name from categories WHERE id=" . $row["house_type"] . "";
            $result2 = $conn->query($sql2);
            while ($row2 = $result2->fetch_assoc()) {
                $houseType = $row2['name'];
            }
            ?>

            <tr>
                <td><?php echo $row['house_number'] ?></td>
                <td>
                    House Type : <?php echo $houseType ?>
                    <br>
                    Description : <?php echo $row["description"] ?>
                    <br>
                    Price : <?php echo $row['price'] ?>
                    <br>
                    Status : <?php echo $row['status'] ?>

                    <input type="hidden" class="house_id_edit" value="<?php echo $row['id'] ?>">
                    <input type="hidden" name="" class="description_current" value="<?php echo $row['description'] ?>">
                    <input type="hidden" name="" class="price_current" value="<?php echo $row['price'] ?>">
                    <input type="hidden" name="" class="house_number_current" value="<?php echo $row['house_number'] ?>">
                    <input type="hidden" name="" class="house_type_edit" value="<?php echo $houseType ?>">

                </td>
                <td>
                    <input type='button' value='Edit' class='btn btn-primary edithouse' data-bs-toggle="modal"
                        data-bs-target="#editHouses">
                   
                </td>
            </tr>



        <?php endwhile ?>

    </tbody>


</table>

<div class="modal fade" id="addHouses" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="add-house.php" method="POST">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Add Houses</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <label for="housenumber">House Number</label>
                    <input type="number" class="form-control" name="housenumber">
                    <label for="categoryType">Category</label>
                    <div class="input-group mb-3">

                        <select class="form-select" id="inputGroupSelect02" name="categoryType">
                            <option selected>Choose...</option>
                            <?php
                            $sql = "SELECT * FROM categories";
                            $result = $conn->query($sql);
                            while ($row = $result->fetch_assoc()) {
                                echo "
                               <option value=" . $row["id"] . ">" . $row["name"] . "</option>";

                            }
                            ?>
                        </select>

                    </div>
                    <label for="description">Description</label>
                    <input type="text" class="form-control description" name="description">
                    <label for="price">Price</label>
                    <input type="number" class="form-control price" name="price">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save House</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- edit -->



<div class="modal fade" id="editHouses" tabindex="-1" aria-labelledby="edithouse" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="edit-house.php" method="POST">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="edithouse">Edit Houses</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <label for="housenumber">House Number</label>
                    <input type="number" class="form-control house_number_edit" name="housenumber">
                    <label for="categoryType">Category</label>
                   <input type="hidden" name="house_id" class="house_id">
                    <label for="description">Description</label>
                    <input type="text" class="form-control " name="description" id="description_edit">
                    <label for="price">Price</label>
                    <input type="number" class="form-control" name="price" id="price_edit">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary cancel_edit " data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="submit">Save House</button>
                </div>
            </form>
        </div>
    </div>
</div>