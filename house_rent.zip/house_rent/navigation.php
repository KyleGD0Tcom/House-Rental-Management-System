<div class="wrapper">
    <!-- =========== Sidebar for admin dashboard =========== -->

    <aside id="sidebar" class="js-sidebar">

        <!-- ======== Content For Sidebar ========-->
        <!-- Content For Sidebar -->
        <div class="h-100">


            <!-- ======= Navigation links for sidebar ======== -->
            <div class="sidebar-logo mx-5 text-uppercase">
                <a href="#">RentEase</a>
            </div>
            <ul class="sidebar-nav">
                <li class="sidebar-header">
                    <span class="material-symbols-outlined">
                        dashboard
                    </span>
                    <p> <a href="dashboard.php">Dashboard</a></p>
                </li>
                <li class="sidebar-header">
                    <span class="material-symbols-outlined">
                        home
                    </span>
                    <p><a href="dashboard.php?page=house-type">House Type</a></p>
                </li>
                <li class="sidebar-header">
                    <span class="material-symbols-outlined">
                        holiday_village
                    </span>
                    <p><a href="dashboard.php?page=houses">Houses</a></p>
                </li>
                <li class="sidebar-header">
                    <span class="material-symbols-outlined">
                        group
                    </span>
                    <p><a href="dashboard.php?page=tenants">Tenants</a></p>
                </li>
                <li class="sidebar-header">
                    <span class="material-symbols-outlined">
                        paid
                    </span>
                    <p><a href="dashboard.php?page=payments">Payments</a></p>
                </li>
                <li class="sidebar-header">
                    <span class="material-symbols-outlined">
                        flag
                    </span>
                    <p><a href="dashboard.php?page=reports">Reports</a></p>
                </li>

            </ul>
        </div>
    </aside>

    <!-- ========= Main section of dashboard ======= -->

    <div class="main">

        <!-- ========= Main navbar section of dashboard ======= -->

        <nav class="navbar navbar-expand px-3 border-bottom" id="topNav">

            <button class="btn" id="sidebar-toggle" type="button">
                <span class="navbar-toggler-icon"></span>
            </button>
            <a class="nav-link dropdown-toggle mx-3" href="#" role="button" data-bs-toggle="dropdown"
                aria-expanded="false">
                Administrator
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="#">Manage Account</a></li>
                <li><a class="dropdown-item" href="logout.php">Logout</a></li>

            </ul>

        </nav>

        <!-- ========= Main content section of dashboard ======= -->

        <div class="container align-self-center px-5" id="main-content">
            <?php
            if (isset($_GET['page'])) {
                $page = htmlspecialchars($_GET['page']);
                $file = $page . '.php';

                if (file_exists($file)) {
                    include $file;
                } else {
                    echo "<p>Page not found.</p>";
                }
            } else {
                include 'main.php';
            }
            ?>
        </div>


    </div>
</div>