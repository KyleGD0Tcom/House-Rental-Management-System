<?php
include 'databaseConn.php';
error_reporting(E_ALL);
ini_set('display_errors', '1');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {

    $id = $_POST['id'];
    $fname = $_POST['firstName'];
    $lname = $_POST['lastName'];
    $mdname = $_POST['midName'];
    $email = $_POST['email'];
    $contact = $_POST['contactNumber'];

    
    $conn->begin_transaction();

    try {
        
        $sql = "UPDATE `tenants` SET `first_name`=?, `last_name`=?, `middle_name`=?, `email`=?, `contact`=? WHERE `id`=?";
        $stmt = $conn->prepare($sql);

        
        $stmt->bind_param("sssssi", $fname, $lname, $mdname, $email, $contact, $id);

    
        if ($stmt->execute()) {

            $conn->commit();
            header("Location: dashboard.php?page=tenants");
            exit;
        } else {
            
            $conn->rollback();
            echo "Error: " . $stmt->error;
        }

        
        $stmt->close();
    } catch (Exception $e) {
       
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }
}


$conn->close();
?>
